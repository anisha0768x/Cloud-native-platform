"""API Gateway application package."""
