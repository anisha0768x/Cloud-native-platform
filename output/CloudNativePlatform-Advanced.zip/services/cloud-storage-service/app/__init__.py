"""Cloud storage service."""
