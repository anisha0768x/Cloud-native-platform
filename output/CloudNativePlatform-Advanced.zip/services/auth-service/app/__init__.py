"""Authentication service package."""
