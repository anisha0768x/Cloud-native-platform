"""GenAI log analysis service."""
