# Helio Operations

Helio Operations is a self-contained cloud-native operations console. It is a runnable product slice of the architecture in the supplied brief: service health, Kubernetes posture, alert workflows, traffic forecasts, maintenance risk, log analysis, and scaling actions are all backed by an API and persisted locally.

## Design

The full enterprise architecture is documented in [docs/architecture.md](docs/architecture.md). For a local, zero-dependency demonstration, this repository deliberately uses a modular Python HTTP API and SQLite. Its HTTP contracts map directly to the separately deployable services described in the target architecture; the UI does not depend on mock-only browser state.

## Run

Requires Python 3.11+. Install platform dependencies once with `python -m pip install -e .`.

```powershell
python run_local.py
```

Open http://localhost:8080. Sign in with `operator@helio.dev` / `demo123`.

Interactive API documentation is available at http://localhost:8080/docs.

The server creates `data/helio.db` on its first run. Delete that file to reset demo data.

## Run every independent backend service

With Docker available, the full local dependency stack plus the independently runnable service processes can be started with:

```powershell
docker compose -f infra/docker-compose.yml -f infra/services.compose.yml up --build
```

The browser entry point stays on port `8080`. Services are exposed on ports `8002`–`8012` for contract inspection; each provides `/health`, `/ready`, and Swagger at `/docs`.

## API surface

- `POST /api/auth/login`
- `GET /api/overview`, `/api/services`, `/api/alerts`, `/api/kubernetes`, `/api/predictions`, `/api/logs`
- `POST /api/alerts/{id}/acknowledge`
- `POST /api/kubernetes/scale`
- `POST /api/logs/analyze`

Additional master-platform contracts exposed through the local API gateway:

- `POST /api/v1/metrics/ingest`, `GET /api/v1/metrics/query`, `GET /api/v1/metrics/latest`
- `GET /api/v1/predictions/traffic/{service_id}`, `GET /api/v1/predictions/maintenance/{service_id}`
- `GET /api/v1/genai/summary/{alert_id}` and `POST /api/v1/notifications/send`
- `GET /api/v1/dashboards/{name}` for all 11 specified dashboards
- `GET /api/v1/k8s/nodes`, `GET /api/v1/k8s/pods`, `PUT /api/v1/configurations`, `GET /api/v1/audit`

All non-auth endpoints require the bearer token returned from login.
